**************NOTE BY GV*************************
The pcap-stdinc.h file has been temporarily added
here before the 3.1final release to store this patched
file somewhere (the vanilla one from libpcap 3.9.3
contains a small error).
The modification has been however committed to the
libpcap CVS.
******************** WARNING ********************

The file "gencode.c" contains *also* a modification tht is required *ONLY* when releasing the code for Cisco Guys. This includes the support for capturing and filtering Boardwalk frames. Therefore, the modification into it must be applied only on the code that goes to Cisco.

For the same reason, the files "cisco-fchack.*" must be present *ONLY* in the version for Cisco.

gencode.c
=========

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef HAVE_REMOTE
#include "cisco-fchack.h"
#endif

#ifdef WIN32
#include <pcap-stdinc.h>
#else /* WIN32 */
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#endif /* WIN32 */

......

int
pcap_compile(pcap_t *p, struct bpf_program *program,
	     char *buf, int optimize, bpf_u_int32 mask)
{
	extern int n_errors;
	int len;

#ifdef HAVE_REMOTE
	char newbuf[NEW_COMPILE_BUF + 1];
	int old_linktype;

	if (filter_translate(p, buf, newbuf) )
		return -1;
	
	/*
		In case we have one of the new DLT_CISCOVEGAS or DLT_CISCOEISL link types, it updates
		the linktype in order to be DLT_EN10MB on the following calls (since this is the real
		link type).
	*/
	old_linktype= p->linktype;

	if (p->linktype == DLT_CISCOVEGAS)
		p->linktype= DLT_EN10MB;
#endif	

	no_optimize = 0;
	n_errors = 0;
	root = NULL;
	bpf_pcap = p;
	if (setjmp(top_ctx)) {
		lex_cleanup();
		freechunks();
		return (-1);
	}

	netmask = mask;

	snaplen = pcap_snapshot(p);
	if (snaplen == 0) {
		snprintf(p->errbuf, PCAP_ERRBUF_SIZE,
			 "snaplen of 0 rejects all packets");
		return -1;
	}

#ifdef HAVE_REMOTE
	lex_init(newbuf ? newbuf : "");
#else
	lex_init(buf ? buf : "");
#endif	
	init_linktype(pcap_datalink(p));
	(void)pcap_parse();

	if (n_errors)
		syntax();

	if (root == NULL)
		root = gen_retblk(snaplen);

	if (optimize && !no_optimize) {
		bpf_optimize(&root);
		if (root == NULL ||
		    (root->s.code == (BPF_RET|BPF_K) && root->s.k == 0))
			bpf_error("expression rejects all packets");
	}
	program->bf_insns = icode_to_fcode(root, &len);
	program->bf_len = len;

	lex_cleanup();
	freechunks();
#ifdef HAVE_REMOTE
	p->linktype= old_linktype;
#endif	

******************** REMEMBER ********************
Remember to update the version number of wpcap.dll in order to differentiate the new version
Rembember to include cisco-fchack.c into the project file
