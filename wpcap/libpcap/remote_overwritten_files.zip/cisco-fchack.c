/*
 * Copyright (c) 2002
 * NetGroup, Politecnico di Torino (Italy)
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 * notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright 
 * notice, this list of conditions and the following disclaimer in the 
 * documentation and/or other materials provided with the distribution. 
 * 3. Neither the name of the Politecnico di Torino nor the names of its 
 * contributors may be used to endorse or promote products derived from 
 * this software without specific prior written permission. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */


#include <string.h>
#include "cisco-fchack.h"
#include <pcap-int.h>
#include "sockutils.h"			// for SOCK_ASSERT macro

/****************************************************
 *                                                  *
 * Patch to compile FC filters (Cisco defined)      *
 *                                                  *
 ****************************************************/


#define MAPTABLE_ITEMS 34
#define REPLACETABLE_ITEMS 5


/*!	\ingroup PriGroup
	\brief Checks if some Fibre Chenner filter is present and, if so, 
	it translates into knoen commands

	This function si just a patch in order to avoid modifying the libcap compiler.
	Therefore, do not expect it will be always working; several simplifications
	have been made.

	\param fp: a pointer to the pcap_t structure currently in use. It is needed to check the
	linktype and to set errbuf (if needed).

	\param buffer: buffer that contains the filter as it has been written by the user.

	\param newbuffer: new buffer (allocated by the user), which will contain the new filter.

	\return '0' if everything is fine, '-1' if some errors occurred. The error message is returned
	in the 'errbuf' field of 'fp'.

	\warning This function does not have any check for buffer overflows, just because this is an
	hack, so we do not want to make things too complicated.
	In any case, the worst thing it can happen is that the application (e.g. ethereal) crashes.
*/
int filter_translate(pcap_t *fp, char *buffer, char *newbuffer)
{
char tempstring[NEW_COMPILE_BUF + 1];
char *ptr;
int i;

static struct MapTableStruct
{
	const char *tag;
	const char *transVegas;
	const char *transEISL;
} MapTable[] =
{
	/* Vegas - EISL basic headers  - 12 items*/
	{ "vsan",			"(ether[14+12:2] & 0x0FFF)",		"(ether[14+4:3] & 0x01FE)"		},
	{ "src_port_idx",	"(ether[14+6:2] & 0x0003FF)",		""								},
	{ "dst_port_idx",	"(ether[14+5:2] & 0x000FFC)",		""								},
	{ "SOF",			"(ether[14+2:1] & 0x0F)",			"ether[14+3:1]"					},
	{ "r_ctl",			"ether[14+16:1]",					"ether[14+10:1]"				},
	{ "d_id",			"(ether[14+16:4] & 0x00FFFFFF)",	"(ether[14+10:4] & 0x00FFFFFF)"	},
	{ "s_id",			"(ether[14+20:4] & 0x00FFFFFF)",	"(ether[14+14:4] & 0x00FFFFFF)"	},
	{ "type",			"ether[14+24:1]",					"ether[14+18:1]"				},
	{ "seq_id",			"ether[14+28:1]",					"ether[14+22:1]"				},
	{ "seq_cnt",		"ether[14+30:2]",					"ether[14+24:2]"				},
	{ "ox_id",			"ether[14+32:2]",					"ether[14+26:2]"				},
	{ "rx_id",			"ether[14+34:2]",					"ether[14+28:2]"				},

	/* Protocols carried by the FC - 7 items */
	{ "els",		"(r_ctl == 0x22 || r_ctl == 0x23) && (type == 1)",		"(r_ctl == 0x22 || r_ctl == 0x23) && (type == 1)"		},
	{ "swils",		"(r_ctl == 0x02 || r_ctl == 0x03) && (type == 0x22)",	"(r_ctl == 0x02 || r_ctl == 0x03) && (type == 0x22)"	},
	{ "fcp_cmd",	"(r_ctl == 0x06) && (type == 0x08)",					"(r_ctl == 0x06) && (type == 0x08)"						},
	{ "fcp_data",	"(r_ctl == 0x01) && (type == 0x08)",					"(r_ctl == 0x01) && (type == 0x08)"						},
	{ "fcp_rsp",	"(r_ctl == 0x07) && (type == 0x08)",					"(r_ctl == 0x07) && (type == 0x08)"						},
	{ "class_f",	"SOF == 0x08",											"SOF == 0x08"											},
	{ "bad_fc",		"(eof == 0x04) || (eof == 0x07)",						"(eof == 0x04) || (eof == 0x07)"						},

	/* Protocol-related fields - 6 items*/
	{ "els_cmd",		"(els) && ether[14+40:1]",			"(els) && ether[14+34:1]",		},
	{ "swils_cmd",		"(swils) && ether[14+40:1]",		"(swils) && ether[14+34:1]",	},
	{ "fcp_lun",		"(swils) && ether[14+40:4]",		"(swils) && ether[14+34:4]",	}, /* WARNING take care; only first 4 bytes */
	{ "fcp_task_mgmt",	"(fcp_cmd) && ether[14+50:1]",		"(fcp_cmd) && ether[14+44:1]",	},
	{ "fcp_scsi_cmd",	"(fcp_cmd) && ether[14+52:1]",		"(fcp_cmd) && ether[14+46:1]",	},
	{ "fcp_status",		"(fcp_rsp) && ether[14+51:1]",		"(fcp_cmd) && ether[14+45:1]",	},

	/* Filters applicable only if r_ctl is 0x2 or 0x3 and the type is 0x20 - 5 items */ 
	{ "gs_type",		"(r_ctl == 0x02 || r_ctl == 0x03) && (type == 0x20) && ether[14+44:1]",		"(r_ctl == 0x02 || r_ctl == 0x03) && (type == 0x20) && ether[14+38:1]",	},
	{ "gs_subtype",		"(r_ctl == 0x02 || r_ctl == 0x03) && (type == 0x20) && ether[14+45:1]",		"(r_ctl == 0x02 || r_ctl == 0x03) && (type == 0x20) && ether[14+39:1]",	},
	{ "gs_cmd",			"(r_ctl == 0x02 || r_ctl == 0x03) && (type == 0x20) && ether[14+48:2]",		"(r_ctl == 0x02 || r_ctl == 0x03) && (type == 0x20) && ether[14+42:2]",	},
	{ "gs_reason",		"(r_ctl == 0x02 || r_ctl == 0x03) && (type == 0x20) && ether[14+53:1]",		"(r_ctl == 0x02 || r_ctl == 0x03) && (type == 0x20) && ether[14+47:1]",	},
	{ "gs_reason_expl",	"(r_ctl == 0x02 || r_ctl == 0x03) && (type == 0x20) && ether[14+54:1]",		"(r_ctl == 0x02 || r_ctl == 0x03) && (type == 0x20) && ether[14+48:1]",	},

	/* Filters for FC applications - 4 items */ 
	{ "dns",	"(gs_type == 0xFC) && (gs_subtype == 0x02)",	"(gs_type == 0xFC) && (gs_subtype == 0x02)",	},
	{ "udns",	"(gs_type == 0xFA) && (gs_subtype == 0x02)",	"(gs_type == 0xFA) && (gs_subtype == 0x02)",	},
	{ "fcs",	"(gs_type == 0xFA) && (gs_subtype == 0x01)",	"(gs_type == 0xFA) && (gs_subtype == 0x01)",	},
	{ "zs",		"(gs_type == 0xFA) && (gs_subtype == 0x03)",	"(gs_type == 0xFA) && (gs_subtype == 0x03)",	},
};


static struct ReplaceTable
{
	const char *tag;
	int offsVegas;
	int offsEISL;
} ReplaceTable[] =
{
	{ "fc[", 16, 10 },
	{ "els[", 40, 34 },
	{ "swils[", 40, 34 },
	{ "fcp[", 40, 34 },
	{ "fcct[", 40, 34 },
};

	if ((buffer == NULL) || (*buffer == 0))
	{
		*newbuffer= 0;
		return 0;
	}

	snprintf(newbuffer, NEW_COMPILE_BUF, "%s", buffer);

	// DLT_CISCOVEGAS are frame captured on Vegas;
	// DLT_EN10MB are frames captured with boardwalk
	if ( (fp->linktype != DLT_CISCOVEGAS) && (fp->linktype != DLT_EN10MB) )
		return 0;

// Look for items into the replace table
replagain:
	for (i= (REPLACETABLE_ITEMS - 1); i >= 0 ; i--)
	{
		if ( (ptr= strstr(newbuffer, ReplaceTable[i].tag) ) )
		{
		int offset, len = 1 /* default length is 1 byte */;

			// copy the string before the tag that has to be replaced
			strncpy(tempstring, newbuffer, ptr - newbuffer);
			tempstring[ptr - newbuffer]= 0;

			// Copy the tag that has to be replaced, without square brackets
			strncat(tempstring, ptr, strlen( ReplaceTable[i].tag) - 1);

			sscanf(ptr + strlen(ReplaceTable[i].tag), "%d:%d", &offset, &len);

			// point o the next char in the string which follows the close square bracket
			ptr= strchr(ptr, ']') + 1;

			if (fp->linktype == DLT_CISCOVEGAS)
				sprintf( &tempstring[strlen(tempstring)], " and ether[%d:%d] %s", offset + ReplaceTable[i].offsVegas, len, ptr);
			else
				sprintf( &tempstring[strlen(tempstring)], " and ether[%d:%d] %s", offset + ReplaceTable[i].offsEISL, len, ptr);

			strcpy(newbuffer, tempstring);
			goto replagain;
		}
	}


again:
	for (i= (MAPTABLE_ITEMS - 1); i>= 0 ; i--)
	{
		if ( (ptr= strstr(newbuffer, MapTable[i].tag) ) )
		{
			// copy the string before the tag that has to be replaced
			strncpy(tempstring, newbuffer, ptr - newbuffer);
			tempstring[ptr - newbuffer]= 0;

			if (fp->linktype == DLT_CISCOVEGAS)
			{
				if (*MapTable[i].transVegas == 0)
				{
					snprintf(fp->errbuf, PCAP_ERRBUF_SIZE, "This filter is not allowed with this linktype");
					return -1;
				}
				strcat(tempstring, MapTable[i].transVegas);
			}
			else
			{
				if (*MapTable[i].transEISL == 0)
				{
					snprintf(fp->errbuf, PCAP_ERRBUF_SIZE, "This filter is not allowed with this linktype");
					return -1;
				}
				strcat(tempstring, MapTable[i].transEISL);
			}

			strcat(tempstring, ptr + strlen(MapTable[i].tag) );
			strcpy(newbuffer, tempstring);
			goto again;
		}
	}

	// Just for debug, to see if the filter is correct
	SOCK_ASSERT("New filter is", 1);
	SOCK_ASSERT(newbuffer, 1);

	return 0;
}
/*
+---------------------------------------------------------------------------+
| Field name (length in bits)   | Offset if Vegas Hdr | Offset of EISL      |
|                               |(bitmask if required)|(bitmask if required)|
+---------------------------------------------------------------------------+
| vsan (12)                     |       13 (0x0FFF)   |   5 (0x1FE)         |
| src_port_idx (10)             |       7 (0x3FF)     |   N/A               | **
| dst_port_idx (10)             |       6 (0xFFC)     |   N/A               | **
| SOF (4)                       |       3 (0xF)       |   4, 1byte len      | **
| r_ctl (8)                     |       17            |   11                |
| d_id (24)                     |       18            |   12                |
| s_id (24)                     |       22            |   16                |
| type (8)                      |       25            |   19                |
| seq_id (8)                    |       29            |   23                |
| seq_cnt (16)                  |       31            |   25                |
| ox_id (16)                    |       33            |   27                |
| rx_id (16)                    |       35            |   29                |
+---------------------------------------------------------------------------+
That completes the basic FC/EISL or FC/Vegas header. The remaining fields are
dependent on the protocol carried by the FC (determined by the combination of
SOF, R_CTL and TYPE fields.

els = (r_ctl == 0x22 || r_ctl == 0x23) && (type == 1)
swils = (r_ctl == 0x2 || r_ctl == 0x3) && (type == 0x22)
fcp_cmd = (r_ctl == 0x6) && (type == 0x8)
fcp_data = (r_ctl == 0x1) && (type == 0x8)
fcp_rsp = (r_ctl == 0x7) && (type == 0x8)
class_f = (sof == 0x8)
bad_fc = (eof == 0x4) || (eof == 0x7)

+---------------------------------------------------------------------------+
| Field name (length in bits)   | Offset if Vegas Hdr | Offset of EISL      |
|                               |(bitmask if required)|(bitmask if required)|
+---------------------------------------------------------------------------+
| els_cmd (8)                   |       41            |   35                |
| swils_cmd (8)                 |       41            |   35                |
| fcp_lun(64)                   |       41            |   35                |
| fcp_task_mgmt (8)             |       51            |   45                |
| fcp_scsi_cmd (8)              |       53            |   47                |
| fcp_status(8)                 |       52            |   46                |
+---------------------------------------------------------------------------+

els_cmd is only present in els frames
swils_cmd is only present in swils frames
fcp_lun, fcp_task_mgmt and fcp_scsi_cmd can only be present in fcp_cmd frames
fcp_status is present only in fcp_rsp frames.

The next set of filters are for GS-3 and they're a little trickier and so I'm
listing them separately.

All the following filters are applicable only if r_ctl is 0x2 or 0x3 and the
type is 0x20.

+---------------------------------------------------------------------------+
| Field name (length in bits)   | Offset if Vegas Hdr | Offset of EISL      |
|                               |(bitmask if required)|(bitmask if required)|
+---------------------------------------------------------------------------+
| gs_type (8)                   |       45            |    39               |
| gs_subtype (8)                |       46            |    40               |
| gs_cmd (16)                   |       49            |    43               |
| gs_reason (8)                 |       54            |    48               |
| gs_reason_expl (8)            |       55            |    49               |
+---------------------------------------------------------------------------+

dns = (gs_type == 0xFC) && (gs_subtype == 0x2)
udns = (gs_type == 0xFA) && (gs_subtype == 0x2)
fcs = (gs_type == 0xFA) && (gs_subtype == 0x1)
zs = (gs_type == 0xFA) && (gs_subtype == 0x3)

It'd also be useful if we could allow users to provide their own filters via
saying els[5:2] which we could appropriately translate as "(r_ctl == 0x22 ||
r_ctl == 0x23) && (type == 1) && els[5:2]". We need to translate els/swils etc
assuming that they start at offset 41 for frames with vegas header and 35 for
frames with EISL header. The names that'd be useful are: 
fc - starting at offset 17 for Vegas hdr frames and 11 for EISL frames
els - starting at offset 41 for Vegas hdr frames and 35 for EISL frames
swils - starting at offset 41 for Vegas hdr frames and 35 for EISL frames
fcp - starting at offset 41 for Vegas hdr frames and 35 for EISL frames
fcct - starting at offset 41 for Vegas hdr frames and 35 for EISL frames
*/
